const allmenu =  ` 
*ꜱᴋʏʙᴜɢ*
┏━━⊱
┣❏ igdl
┣❏ igdl2
┣❏ twtdl
┣❏ fbdl
┗━━⊱
*Download Maker*
┏━━⊱
┣❏tiktok
┣❏play
┣❏mediafire
┗━━⊱
*Game Maker*
┏━━⊱
┣❏rpgmenu
┣❏tebak
┣❏jadian
┗━━⊱
*Sticker Maker*
┏━━⊱
┣❏sticker
┣❏stickergif
┣❏emojimix
┣❏emojimix2
┣❏smeme
┗━━⊱
*Audio & Image*
┏━━⊱
┣❏toimage 
┣❏tomp4
┣❏tovn
┣❏togif
┣❏tourl 
┣❏toaud
┗━━⊱
*Image Maker*
┏━━⊱
┣❏pinterest
┣❏couple
┣❏coffe
┗━━⊱
*Only Group*
┏━━⊱
┣❏inspect
┣❏linkgroup
┣❏tagall
┣❏hidetag
┣❏group
┣❏setname
┣❏setdesc
┣❏editinfo
┣❏setppgroup
┗━━⊱
*Only Owner*
┏━━⊱
┣❏listpc
┣❏listgc
┣❏listonline
┣❏setppbot
┣❏block
┣❏unblock
┗━━⊱
*Cmd Maker*
┏━━⊱
┣❏listcmd
┣❏setcmd [ reply sticker ]
┣❏delcmd [ reply sticker ]
┗━━⊱
*Random*
┏━━⊱
┣❏ktpmaker
┣❏afk
┣❏ping
┣❏owner
┣❏kalkulator
┣❏getname
┣❏getpic
┣❏infochat
┣❏q
┣❏del
┣❏style
┣❏ss
┣❏penjara
┗━━⊱[ ꜱᴋʏʙᴜɢ ]`
exports.allmenu = allmenu