const rpgmenu =  ` 
*RPG MENU*
┏━━⊱
┣❏leaderboard
┣❏inventori
┣❏mining
┣❏beli
┣❏jual
┣❏heal
┣❏berburu
┗━━⊱[ ꜱᴋʏʙᴜɢ ]`
exports.rpgmenu = rpgmenu