const menu =  ` 
° Owner  : Hidden
° Version : 12
° Baileys : 4.4.0
 ▰▱▰▱▰▱▰▱▰▱▰▱▰▱
 ❍ BUG_MENU ❍
┏━━⊱
┣❏ Bugmenu
┗━━⊱
 ❍ ALL_MENU ❍
┏━━⊱
┣❏ Allmenu
┗━━⊱
❍ MENU_MODS ❍
┏━━⊱
┣❏ Sewa
┣❏ Logo
┣❏ Textmaker
┣❏ Belajarkita
┣❏ Methodeband
┣❏ Listjualan
┣❏ Listowner
┣❏ Listwibu
┣❏ Nowa 628xxx
┣❏ Verif 62xxxxx
┣❏ Ban add 628xx
┣❏ User add 62xx
┣❏ User del 62xxx
┗━━⊱
❍ MENU_GROUP ❍
┏━━⊱
┣❏ Antilink on / off
┣❏ Welcome on / off
┣❏ Detectadmin on / off
┣❏ Kick 628xxx
┣❏ Add 628xxx
┣❏ Promote 628xx
┣❏ Demote 628xx
┗━━⊱
ꜱᴋʏʙᴜɢ`
exports.menu = menu